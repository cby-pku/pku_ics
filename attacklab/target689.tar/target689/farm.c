/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_153(unsigned x)
{
    return x + 3277357682U;
}

unsigned addval_126(unsigned x)
{
    return x + 2428995656U;
}

void setval_287(unsigned *p)
{
    *p = 3281017057U;
}

void setval_183(unsigned *p)
{
    *p = 3347663092U;
}

unsigned getval_121()
{
    return 3347663881U;
}

void setval_452(unsigned *p)
{
    *p = 1351398216U;
}

unsigned addval_375(unsigned x)
{
    return x + 3347662915U;
}

unsigned getval_342()
{
    return 3281031248U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_270(unsigned *p)
{
    *p = 2425405833U;
}

unsigned getval_175()
{
    return 3286272328U;
}

unsigned getval_439()
{
    return 2464188744U;
}

unsigned getval_423()
{
    return 3372794248U;
}

unsigned addval_488(unsigned x)
{
    return x + 3687104905U;
}

unsigned addval_434(unsigned x)
{
    return x + 3767093383U;
}

void setval_133(unsigned *p)
{
    *p = 2497087752U;
}

unsigned addval_326(unsigned x)
{
    return x + 3286280520U;
}

unsigned getval_400()
{
    return 3281114761U;
}

void setval_394(unsigned *p)
{
    *p = 2425670281U;
}

unsigned getval_256()
{
    return 3375939977U;
}

unsigned getval_413()
{
    return 3376988553U;
}

unsigned addval_425(unsigned x)
{
    return x + 3676357005U;
}

unsigned getval_147()
{
    return 2430632264U;
}

void setval_354(unsigned *p)
{
    *p = 2429995397U;
}

unsigned addval_187(unsigned x)
{
    return x + 3531917960U;
}

unsigned addval_330(unsigned x)
{
    return x + 3229931137U;
}

void setval_156(unsigned *p)
{
    *p = 3229931145U;
}

unsigned addval_152(unsigned x)
{
    return x + 3376988553U;
}

unsigned getval_261()
{
    return 2425473673U;
}

void setval_134(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_471()
{
    return 3682912937U;
}

unsigned addval_472(unsigned x)
{
    return x + 3380920777U;
}

void setval_469(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_491()
{
    return 3372796569U;
}

unsigned getval_402()
{
    return 3526940361U;
}

void setval_267(unsigned *p)
{
    *p = 3767077039U;
}

unsigned addval_327(unsigned x)
{
    return x + 3281046153U;
}

unsigned addval_392(unsigned x)
{
    return x + 918801033U;
}

void setval_157(unsigned *p)
{
    *p = 3229928077U;
}

unsigned addval_378(unsigned x)
{
    return x + 3687110281U;
}

void setval_466(unsigned *p)
{
    *p = 3285616911U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
